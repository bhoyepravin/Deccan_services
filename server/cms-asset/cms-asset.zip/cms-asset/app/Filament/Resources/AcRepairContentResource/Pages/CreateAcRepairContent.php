<?php

namespace App\Filament\Resources\AcRepairContentResource\Pages;

use App\Filament\Resources\AcRepairContentResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateAcRepairContent extends CreateRecord
{
    protected static string $resource = AcRepairContentResource::class;
}
