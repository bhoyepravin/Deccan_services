<?php

namespace App\Filament\Resources\WaterPurifierRepairResource\Pages;

use App\Filament\Resources\WaterPurifierRepairResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateWaterPurifierRepair extends CreateRecord
{
    protected static string $resource = WaterPurifierRepairResource::class;
}
