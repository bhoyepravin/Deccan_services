<div
    <?php echo e($attributes
            ->merge([
                'id' => $getId(),
            ], escape: false)
            ->merge($getExtraAttributes(), escape: false)); ?>

>
    <?php echo e($getChildComponentContainer()); ?>

</div>
<?php /**PATH D:\RICH SYSTEM SOLUTIONS\Project_Hosted Done\Deccan_services\server\cms-asset\cms-asset\vendor\filament\forms\src\/../resources/views/components/group.blade.php ENDPATH**/ ?>